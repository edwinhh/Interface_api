from SIT_tool.pyflask.lib.MyDB import MyDB
from SIT_tool.pyflask.lib.readconfig import getdb
from SIT_tool.pyflask.lib.readconfig import getsql

class jira():
	def __init__(self,list):
		self.host = list[0]
		self.username = list[1]
		self.password = list[2]
		self.port = int(list[3])
		self.database = list[4]
		self.mydb = MyDB(self.host, self.username, self.password, self.port, self.database)
	
	def rds(self,project,version):
		sql1 = getsql('rds', 'sql1')
		sql=sql1%(project,version)
		return self.mydb.query(sql)
	
	def rds_order(self):
		sql = getsql('rds', 'sql2')
		return self.mydb.query(sql)


# jira1=jira(getdb('jira'))
jira=jira(getdb('jira'))
k=jira.rds('GIS_ASS_RDS','V3.9')
print(k)
print(type(k))
#
# k2=jira1.rds_order()
# print(k2)
